// Determines if the current browser is Internet Explorer.
module.exports = /(MSIE|Trident\/|Edge\/)/i.test(navigator.userAgent);
